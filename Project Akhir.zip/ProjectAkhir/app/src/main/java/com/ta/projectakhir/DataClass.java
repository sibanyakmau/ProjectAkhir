package com.ta.projectakhir;

public class DataClass {
    private String namaBarang;
    private String hargaBarang;
    private String jumlahBarang;
    private String fotoBarang;
    private String key;

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getNamaBarang() {
        return namaBarang;
    }

    public String getHargaBarang() {
        return hargaBarang;
    }

    public String getJumlahBarang() {
        return jumlahBarang;
    }

    public String getFotoBarang() {
        return fotoBarang;
    }

    public DataClass(String namaBarang, String hargaBarang, String jumlahBarang, String fotoBarang) {
        this.namaBarang = namaBarang;
        this.hargaBarang = hargaBarang;
        this.jumlahBarang = jumlahBarang;
        this.fotoBarang = fotoBarang;
    }

    public DataClass(){

    }
}
